import * as d3Scales from 'victory-vendor/d3-scale';
import { upperFirst } from '../../../util/DataUtils';
function isSupportedScaleName(name) {
  return name in d3Scales;
}
export var combineRealScaleType = (axisConfig, hasBar, chartType) => {
  if (axisConfig == null) {
    return undefined;
  }
  var {
    scale,
    type
  } = axisConfig;
  if (scale === 'auto') {
    if (type === 'category' && chartType && (chartType.indexOf('LineChart') >= 0 || chartType.indexOf('AreaChart') >= 0 || chartType.indexOf('ComposedChart') >= 0 && !hasBar)) {
      return 'point';
    }
    if (type === 'category') {
      return 'band';
    }
    return 'linear';
  }
  if (typeof scale === 'string') {
    var name = "scale".concat(upperFirst(scale));
    return isSupportedScaleName(name) ? name : 'point';
  }
  return undefined;
};