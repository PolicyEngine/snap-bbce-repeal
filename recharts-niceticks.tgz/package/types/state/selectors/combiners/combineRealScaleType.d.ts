import { D3ScaleType } from '../../../util/types';
import { BaseCartesianAxis } from '../../cartesianAxisSlice';
export declare const combineRealScaleType: (axisConfig: BaseCartesianAxis | undefined, hasBar: boolean, chartType: string) => D3ScaleType | undefined;
